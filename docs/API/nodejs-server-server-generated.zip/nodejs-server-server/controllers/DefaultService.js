'use strict';

exports.client_hsbc_frCgi_binBalancesGET = function(args, res, next) {
  /**
   * This API will return balances data for the connected Customer
   *
   * returns List
   **/
  var examples = {};
  examples['application/json'] = [ {
  "header" : {
    "errMsg" : [ {
      "code" : "aeiou",
      "desc" : "aeiou"
    } ],
    "version" : "aeiou",
    "token" : "aeiou",
    "statusCode" : "aeiou"
  },
  "body" : {
    "entities" : [ {
      "newMsgNumber" : "aeiou",
      "accountGroups" : [ {
        "accounts" : [ {
          "accountDate" : "aeiou",
          "drCr" : true,
          "accountNum" : "aeiou",
          "balance" : "aeiou",
          "ccy" : {
            "code" : "aeiou",
            "desc" : "aeiou"
          },
          "id" : "aeiou",
          "sessionParam" : true,
          "type" : "aeiou",
          "desc" : "aeiou",
          "hasParent" : true
        } ]
      } ]
    } ]
  }
} ];
  if (Object.keys(examples).length > 0) {
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify(examples[Object.keys(examples)[0]] || {}, null, 2));
  } else {
    res.end();
  }
}

