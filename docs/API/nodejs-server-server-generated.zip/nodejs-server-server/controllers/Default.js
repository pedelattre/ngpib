'use strict';

var url = require('url');

var Default = require('./DefaultService');

module.exports.client_hsbc_frCgi_binBalancesGET = function client_hsbc_frCgi_binBalancesGET (req, res, next) {
  Default.client_hsbc_frCgi_binBalancesGET(req.swagger.params, res, next);
};
